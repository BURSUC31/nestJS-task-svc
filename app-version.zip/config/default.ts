server:
port: 3000

db:
type: 'postgres'
port: 5432
database: 'taskmanagement'

jwt:
expiresIn: '2 days'
